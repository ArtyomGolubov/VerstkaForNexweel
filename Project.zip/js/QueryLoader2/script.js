$(document).ready(function () {
    $("body").queryLoader2({
        barColor: "#603e29",
        backgroundColor: "#fafaee",
        percentage: true,
        barHeight: 1,
        completeAnimation: "grow",
        minimumTime: 1000
    });
});